let producto = {
    id: 0,              // Int
    nombre: "",         // String
    modelo: "",         // String
    precio: 0.0,        // Float
    cantidad: 0,        // Int
    descuento: 0,       // Int
    estrellas: 0,       // Int
    esNuevo: false,     // Bool
    categoria: ""       // String
};
