# VENTAS BBB
<h1> Curso express de programación interactiva con js y bootstrap </h1>

Aquí irán las distintas <strong>actividades</strong> y <strong> ejercicos de casa </strong> que tendrán que modificar o cambiar según lo visto en clase o acciones que gusten complemtar.

<h3> Contenido del proyecto: </h3>
<ul>Archivos HTML con diseño responsivo usando <b>Bootstrap 5</b> y diseños CSS propios para una mejor estética</ul>
<ul>Archivos reutilizables a nivel HTML y código JavaScript para mejorar la funcionalidad de la página</ul>
<ul>Imágenes y gifs que permiten visualizar mejor la página o realizar distintas acciones con ellas</ul>
<ul>Funciones y archivo js, algunos inicializados con valores y otros no (mismos que se deberán ir trabajando)</ul>

<h3>Antecedentes que deben tener</h3>
<li>Manejo básico de <b>HTML 5</b> y <b>CSS 3</b> y conocimiento básico de <b>Bootstrap 5</b></li>
<li>Fundamentos de programación básicos</li>
<li>Definición de javascript como lenguaje de programación y su objetivo en el desarrollo web</li>
<li>Conocimiento teórico de frameworks actuales basados en javascript para una mejor aplicación de la tienda</li>
<li>Sintaxis básica de javascript: declarar variables, mostrar mensajes, condicionales, ciclos, arreglos, estructuras e inicialización de valores</li>
<li>Manejo de funciones sin parámetros, con parámetros, funciones anónimas y funciones flecha</li>
<li>Conocimiento teórico del DOM (Document Object Model)</li>

<h1>Retos que se tendrán que cumplir en cada sección</h1>
Ya veremos dijo el ciego
